'use strict';document.documentElement.setAttribute("kv","2100");
